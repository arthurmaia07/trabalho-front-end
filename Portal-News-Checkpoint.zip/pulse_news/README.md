# Portal News - Checkpoint

Projeto desenvolvido em React + TypeScript para o Checkpoint de Front-end Design Engineering.

## Integrantes

- João Arthur Maia Almeida - RM 573458
- Matheus Nogueira Quintas - RM 572542
- Guilherme Ribeiro Matias - RM 573890

## Funcionalidades

- Listagem de 10 notícias
- Busca por título, conteúdo e categoria
- Página completa de cada notícia
- Comentários em componente separado
- Página 404 personalizada
- Layout responsivo

## Como executar

```bash
npm install
npm run dev
```

## Deploy

Adicionar aqui o link público da Vercel após realizar o deploy.
