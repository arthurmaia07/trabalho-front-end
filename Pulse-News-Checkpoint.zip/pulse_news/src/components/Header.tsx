import { Link } from 'react-router-dom';
export function Header(){return <header className="site-header"><div className="container header-inner"><Link className="brand" to="/"><span className="brand-mark">P</span><span>Pulse News</span></Link><nav><Link to="/">Início</Link><a href="#destaques">Destaques</a></nav></div></header>}
