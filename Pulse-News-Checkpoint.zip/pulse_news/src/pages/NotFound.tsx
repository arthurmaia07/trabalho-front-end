import { Link } from 'react-router-dom';
export function NotFound(){return <main className="not-found container"><div className="error-code">404</div><h1>Essa página saiu do radar.</h1><p>O endereço pode ter mudado ou nunca ter existido.</p><Link className="button" to="/">Voltar para as notícias</Link></main>}
