# Pulse News — Checkpoint Front-end Design Engineering

Portal de notícias desenvolvido em React + TypeScript + Vite, com layout responsivo e identidade visual própria.

## Requisitos implementados
- Estrutura organizada em `components`, `pages`, `services`, `types` e `styles`.
- Tipagem TypeScript para notícias e comentários.
- Serviço local simulando uma API com 10 notícias.
- Home com filtro por título, conteúdo e categorias e mensagem de nenhum resultado.
- Conteúdo dos cards limitado a 50 caracteres.
- Página completa da notícia por rota dinâmica.
- Comentários em componente separado, renderizado após o carregamento inicial da tela.
- Navegação de volta para a Home.
- CSS externo, sem CSS inline/interno.
- Responsividade para desktop, tablet e celular.
- Página 404 personalizada.

## Executar
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Deploy Vercel
Após publicar o repositório na Vercel, substitua a linha abaixo pela URL pública:

**URL pública:** ADICIONAR_URL_DA_VERCEL

## Integrantes
Antes da entrega, substitua os placeholders em `src/components/Footer.tsx` pelos nomes completos e RAs dos três integrantes.
