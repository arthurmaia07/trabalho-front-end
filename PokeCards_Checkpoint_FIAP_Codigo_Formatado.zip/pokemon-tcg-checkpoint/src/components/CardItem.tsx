"use client";

import Image from "next/image";
import Link from "next/link";
import type { PokemonCard } from "@/types/pokemon";
import { useFavorites } from "@/context/FavoritesContext";

export default function CardItem({ card }: { card: PokemonCard }) {
  const { isFavorite, toggleFavorite, ready } = useFavorites();
  const favorite = isFavorite(card.id);

  return (
    <article className="pokemon-card">
      <Link className="card-image-link" href={`/cartas/${encodeURIComponent(card.id)}`}>
        <Image
          src={card.images.small}
          alt={`Carta ${card.name}`}
          width={245}
          height={342}
          sizes="(max-width: 620px) 75vw, (max-width: 920px) 38vw, 220px"
          className="card-picture"
        />
      </Link>
      <div className="card-content">
        <h3>{card.name}</h3>
        <p className="card-number">Nº {card.nationalPokedexNumbers?.join(", ") || card.number}</p>
        <div className="card-meta"><span>{card.types?.join(" / ") || "Sem tipo"}</span><span>HP {card.hp || "—"}</span></div>
        <div className="card-actions">
          <Link className="details-link" href={`/cartas/${encodeURIComponent(card.id)}`}>Detalhes</Link>
          <button
            className={`favorite-button ${favorite ? "is-favorite" : ""}`}
            type="button"
            onClick={() => toggleFavorite(card)}
            disabled={!ready}
            aria-label={favorite ? `Remover ${card.name} dos favoritos` : `Favoritar ${card.name}`}
          >
            {favorite ? "♥ Salvo" : "♡ Favoritar"}
          </button>
        </div>
      </div>
    </article>
  );
}
