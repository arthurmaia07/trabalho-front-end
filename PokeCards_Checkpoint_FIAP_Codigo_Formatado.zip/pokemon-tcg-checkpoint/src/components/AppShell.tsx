import type { ReactNode } from "react";
import Header from "@/components/Header";
import { FavoritesProvider } from "@/context/FavoritesContext";

export default function AppShell({ username, children }: { username: string; children: ReactNode }) {
  return (
    <FavoritesProvider username={username}>
      <Header username={username} />
      {children}
      <footer className="footer">
        <div className="container">
          <p>PokéCards • Checkpoint FIAP • Front-end Design Engineering</p>
          <p>Integrante 1: NOME COMPLETO — RA: PREENCHER | Integrante 2: NOME COMPLETO — RA: PREENCHER | Integrante 3: NOME COMPLETO — RA: PREENCHER</p>
        </div>
      </footer>
    </FavoritesProvider>
  );
}
