"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useFavorites } from "@/context/FavoritesContext";

export default function Header({ username }: { username: string }) {
  const router = useRouter();
  const { favorites, clearFavorites } = useFavorites();
  const [leaving, setLeaving] = useState(false);

  async function logout() {
    setLeaving(true);
    try {
      const response = await fetch("/api/auth/logout", { method: "POST" });
      if (!response.ok) throw new Error("Erro ao sair");
      clearFavorites();
      router.replace("/login");
      router.refresh();
    } catch {
      alert("Não foi possível sair. Tente novamente.");
      setLeaving(false);
    }
  }

  return (
    <header className="site-header">
      <div className="container header-inner">
        <Link className="brand" href="/" aria-label="Ir para o início">
          <span className="brand-ball" aria-hidden="true" /> Poké<span>Cards</span>
        </Link>
        <div className="header-actions">
          <span className="greeting">Olá, {username}</span>
          <Link className="favorites-link" href="/#favoritos">♥ Favoritos ({favorites.length})</Link>
          <button className="btn btn-outline" onClick={logout} disabled={leaving}>
            {leaving ? "Saindo..." : "Sair"}
          </button>
        </div>
      </div>
    </header>
  );
}
