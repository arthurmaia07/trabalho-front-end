"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useFavorites } from "@/context/FavoritesContext";
import type { PokemonCard, PokemonDetailResponse } from "@/types/pokemon";

export default function DetailsContent({ id }: { id: string }) {
  const [card, setCard] = useState<PokemonCard | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const { toggleFavorite, isFavorite, ready } = useFavorites();

  useEffect(() => {
    const controller = new AbortController();

    async function loadCard() {
      try {
        const response = await fetch(`/api/cards/${encodeURIComponent(id)}`, { signal: controller.signal });
        const data = await response.json() as PokemonDetailResponse & { error?: string };
        if (!response.ok) throw new Error(data.error || "Erro ao buscar carta.");
        setCard(data.data);
      } catch (err) {
        if (!controller.signal.aborted) setError(err instanceof Error ? err.message : "Erro inesperado.");
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }

    loadCard();
    return () => controller.abort();
  }, [id]);

  return (
    <main className="container details-container">
      <Link href="/" className="back-link">← Voltar para as cartas</Link>
      {loading && <div className="notice">Carregando informações da carta...</div>}
      {error && <div className="notice notice-error">{error}</div>}
      {card && (
        <div className="details-layout">
          <div className="details-image">
            <Image src={card.images.large} alt={`Carta ${card.name}`} width={440} height={612} priority sizes="(max-width: 760px) 90vw, 420px" />
          </div>
          <div className="details-info">
            <p className="eyebrow">DETALHES DA CARTA</p>
            <h1>{card.name}</h1>
            <p className="details-subtitle">{card.set?.name || "Pokémon TCG"} • Nº {card.number}</p>
            <div className="details-badges">
              {card.types?.map((type) => <span key={type}>{type}</span>)}
              <span>HP {card.hp || "—"}</span>
            </div>
            <dl className="details-list">
              <div><dt>Pokédex</dt><dd>{card.nationalPokedexNumbers?.join(", ") || "Não informado"}</dd></div>
              <div><dt>Categoria</dt><dd>{card.supertype || "Não informada"}</dd></div>
              <div><dt>Subtipo</dt><dd>{card.subtypes?.join(", ") || "Não informado"}</dd></div>
              <div><dt>Raridade</dt><dd>{card.rarity || "Não informada"}</dd></div>
              <div><dt>Ilustrador</dt><dd>{card.artist || "Não informado"}</dd></div>
              <div><dt>Coleção</dt><dd>{card.set?.series || "Não informada"}</dd></div>
            </dl>
            {card.attacks && card.attacks.length > 0 && (
              <div className="attacks"><h2>Ataques</h2>{card.attacks.map((attack, index) => (
                <div className="attack" key={`${attack.name}-${index}`}>
                  <strong>{attack.name} {attack.damage && `• ${attack.damage}`}</strong>
                  <p>{attack.text || "Sem descrição."}</p>
                </div>
              ))}</div>
            )}
            {card.flavorText && <p className="flavor-text">“{card.flavorText}”</p>}
            <button className="btn btn-primary detail-favorite" disabled={!ready} onClick={() => toggleFavorite(card)}>
              {isFavorite(card.id) ? "♥ Remover dos favoritos" : "♡ Adicionar aos favoritos"}
            </button>
          </div>
        </div>
      )}
    </main>
  );
}
