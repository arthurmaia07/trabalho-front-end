"use client";

import { useEffect, useState } from "react";
import type { PokemonCard, PokemonListResponse } from "@/types/pokemon";
import { useFavorites } from "@/context/FavoritesContext";
import CardItem from "@/components/CardItem";

export default function HomeContent() {
  const [input, setInput] = useState("");
  const [cards, setCards] = useState<PokemonCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const { favorites } = useFavorites();

  // Pequeno intervalo para não consultar a API a cada tecla digitada.
  useEffect(() => {
    const controller = new AbortController();
    const timer = setTimeout(async () => {
      setLoading(true);
      setError("");

      try {
        const response = await fetch(`/api/cards?search=${encodeURIComponent(input.trim())}`, {
          signal: controller.signal
        });
        const result = await response.json() as PokemonListResponse & { error?: string };
        if (!response.ok) throw new Error(result.error || "Falha na busca.");
        setCards(result.data.slice(0, 15));
      } catch (err) {
        if (controller.signal.aborted) return;
        setError(err instanceof Error ? err.message : "Erro ao procurar cartas.");
        setCards([]);
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }, input.trim() ? 450 : 0);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [input]);

  return (
    <>
      <section className="hero">
        <div className="container hero-content">
          <div className="hero-pill">SUA COLEÇÃO COMEÇA AQUI</div>
          <h1>Encontre suas cartas <span>favoritas.</span></h1>
          <p>Explore o universo Pokémon TCG, conheça os detalhes das cartas e monte sua própria coleção de favoritos.</p>
          <label className="search-label" htmlFor="search">Buscar cartas Pokémon</label>
          <div className="search-box">
            <span aria-hidden="true">⌕</span>
            <input
              id="search"
              value={input}
              onChange={(event) => setInput(event.target.value)}
              type="search"
              maxLength={60}
              placeholder="Digite o nome de um Pokémon..."
            />
            <button type="button" onClick={() => setInput("")} disabled={!input}>Limpar</button>
          </div>
          <small>Exibimos até 15 cartas por busca.</small>
        </div>
      </section>

      <main className="container main-content">
        <div className="section-heading">
          <div>
            <p className="eyebrow">EXPLORE</p>
            <h2>{input ? `Resultados para “${input}”` : "Descubra cartas"}</h2>
          </div>
          <span className="count-chip">{cards.length} cartas</span>
        </div>

        {loading && <div className="notice">Carregando cartas...</div>}
        {!loading && error && <div className="notice notice-error" role="alert">{error}</div>}
        {!loading && !error && cards.length === 0 && (
          <div className="notice">Nenhuma carta encontrada. Tente pesquisar outro nome.</div>
        )}
        {!loading && !error && cards.length > 0 && (
          <div className="cards-grid">{cards.map((card) => <CardItem key={card.id} card={card} />)}</div>
        )}

        <section id="favoritos" className="favorites-section">
          <div className="section-heading">
            <div>
              <p className="eyebrow">SUA COLEÇÃO</p>
              <h2>Meus favoritos <span className="heart">♥</span></h2>
            </div>
            <span className="count-chip">{favorites.length} salvos</span>
          </div>
          {favorites.length === 0 ? (
            <div className="notice">Você ainda não favoritou nenhuma carta. Clique em ♡ Favoritar para começar.</div>
          ) : (
            <div className="cards-grid">{favorites.map((card) => <CardItem key={card.id} card={card} />)}</div>
          )}
        </section>
      </main>
    </>
  );
}
