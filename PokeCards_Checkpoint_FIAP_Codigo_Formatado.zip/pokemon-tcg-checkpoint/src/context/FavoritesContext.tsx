"use client";

import { createContext, useContext, useEffect, useState } from "react";
import type { ReactNode } from "react";
import type { PokemonCard } from "@/types/pokemon";

interface FavoritesContextType {
  favorites: PokemonCard[];
  ready: boolean;
  isFavorite: (id: string) => boolean;
  toggleFavorite: (card: PokemonCard) => void;
  clearFavorites: () => void;
}

const FavoritesContext = createContext<FavoritesContextType | null>(null);

export function FavoritesProvider({ children, username }: {
  children: ReactNode;
  username: string;
}) {
  const [favorites, setFavorites] = useState<PokemonCard[]>([]);
  const [ready, setReady] = useState(false);
  const storageKey = `pokemon-favorites-${username}`;

  useEffect(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      setFavorites(saved ? JSON.parse(saved) as PokemonCard[] : []);
    } catch {
      setFavorites([]);
    }
    setReady(true);
  }, [storageKey]);

  function saveFavorites(cards: PokemonCard[]) {
    setFavorites(cards);
    localStorage.setItem(storageKey, JSON.stringify(cards));
  }

  function isFavorite(id: string) {
    return favorites.some((card) => card.id === id);
  }

  function toggleFavorite(card: PokemonCard) {
    if (!ready) return;
    if (isFavorite(card.id)) {
      saveFavorites(favorites.filter((item) => item.id !== card.id));
    } else {
      saveFavorites([...favorites, card]);
    }
  }

  function clearFavorites() {
    setFavorites([]);
    localStorage.removeItem(storageKey);
  }

  return (
    <FavoritesContext.Provider value={{ favorites, ready, isFavorite, toggleFavorite, clearFavorites }}>
      {children}
    </FavoritesContext.Provider>
  );
}

export function useFavorites() {
  const context = useContext(FavoritesContext);
  if (!context) throw new Error("useFavorites precisa estar dentro do FavoritesProvider.");
  return context;
}
