"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setLoading(true);

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Erro ao entrar.");

      router.replace("/");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro inesperado.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="login-page">
      <div className="login-decoration" aria-hidden="true"><div className="giant-pokeball" /></div>
      <div className="login-panel">
        <div className="login-brand"><span className="brand-ball" /> Poké<span>Cards</span></div>
        <p className="eyebrow">BEM-VINDO DE VOLTA</p>
        <h1>Sua coleção começa aqui.</h1>
        <p className="login-subtitle">Faça login para pesquisar cartas Pokémon e guardar suas favoritas.</p>
        <form onSubmit={handleSubmit}>
          <label htmlFor="username">Usuário</label>
          <input id="username" type="text" value={username} maxLength={50} autoComplete="username" required
            onChange={(event) => setUsername(event.target.value)} placeholder="Seu nome de usuário" />
          <label htmlFor="password">Senha</label>
          <input id="password" type="password" value={password} autoComplete="current-password" required
            onChange={(event) => setPassword(event.target.value)} placeholder="Digite sua senha" />
          {error && <div className="login-error" role="alert">{error}</div>}
          <button className="btn btn-primary login-submit" type="submit" disabled={loading}>
            {loading ? "Entrando..." : "Entrar na coleção →"}
          </button>
        </form>
        <p className="login-footnote">Projeto acadêmico • FIAP • 2026</p>
      </div>
    </main>
  );
}
