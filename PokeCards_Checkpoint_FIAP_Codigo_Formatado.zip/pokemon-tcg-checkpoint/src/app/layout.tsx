import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PokéCards | Minhas cartas favoritas",
  description: "Busque cartas Pokémon TCG e salve suas favoritas."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
