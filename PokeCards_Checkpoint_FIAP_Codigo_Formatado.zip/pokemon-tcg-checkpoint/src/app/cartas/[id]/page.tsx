import { redirect } from "next/navigation";
import { getLoggedInUser } from "@/lib/session";
import AppShell from "@/components/AppShell";
import DetailsContent from "@/components/DetailsContent";

export const dynamic = "force-dynamic";

export default async function CardDetailsPage({ params }: {
  params: Promise<{ id: string }>;
}) {
  const username = await getLoggedInUser();
  if (!username) redirect("/login");
  const { id } = await params;

  return <AppShell username={username}><DetailsContent id={id} /></AppShell>;
}
