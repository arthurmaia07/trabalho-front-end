import { redirect } from "next/navigation";
import { getLoggedInUser } from "@/lib/session";
import AppShell from "@/components/AppShell";
import HomeContent from "@/components/HomeContent";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const username = await getLoggedInUser();
  if (!username) redirect("/login");

  return <AppShell username={username}><HomeContent /></AppShell>;
}
