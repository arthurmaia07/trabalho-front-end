import { NextRequest, NextResponse } from "next/server";
import { getLoggedInUser } from "@/lib/session";
import { getCard } from "@/lib/pokemon-api";

export async function GET(
  _request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  if (!await getLoggedInUser()) {
    return NextResponse.json({ error: "Faça login para consultar esta carta." }, { status: 401 });
  }

  try {
    const { id } = await context.params;
    return NextResponse.json(await getCard(id));
  } catch (error) {
    return NextResponse.json({
      error: error instanceof Error ? error.message : "Erro inesperado."
    }, { status: 502 });
  }
}
