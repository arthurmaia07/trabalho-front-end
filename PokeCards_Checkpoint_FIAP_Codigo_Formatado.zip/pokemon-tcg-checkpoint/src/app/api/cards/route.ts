import { NextRequest, NextResponse } from "next/server";
import { getLoggedInUser } from "@/lib/session";
import { listCards } from "@/lib/pokemon-api";

export async function GET(request: NextRequest) {
  if (!await getLoggedInUser()) {
    return NextResponse.json({ error: "Faça login para consultar as cartas." }, { status: 401 });
  }

  try {
    const search = (request.nextUrl.searchParams.get("search") || "").slice(0, 60);
    return NextResponse.json(await listCards(search));
  } catch (error) {
    return NextResponse.json({
      error: error instanceof Error ? error.message : "Erro inesperado."
    }, { status: 502 });
  }
}
