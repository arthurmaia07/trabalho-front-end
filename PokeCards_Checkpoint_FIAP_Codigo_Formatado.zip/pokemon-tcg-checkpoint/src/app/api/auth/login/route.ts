import { NextRequest, NextResponse } from "next/server";
import { COOKIE_NAME, createSession } from "@/lib/session";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const username = typeof body.username === "string" ? body.username.trim() : "";
    const password = typeof body.password === "string" ? body.password : "";
    const correctPassword = process.env.LOGIN_PASSWORD;

    if (!username || username.length > 50 || !password) {
      return NextResponse.json({ error: "Informe usuário e senha." }, { status: 400 });
    }

    if (!correctPassword) {
      return NextResponse.json({ error: "A senha do projeto não foi configurada no servidor." }, { status: 500 });
    }

    if (password !== correctPassword) {
      return NextResponse.json({ error: "Senha incorreta. Tente novamente." }, { status: 401 });
    }

    const token = createSession(username);
    const response = NextResponse.json({ success: true });
    response.cookies.set(COOKIE_NAME, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24
    });
    return response;
  } catch {
    return NextResponse.json({ error: "Dados inválidos." }, { status: 400 });
  }
}
