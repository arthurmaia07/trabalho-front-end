export interface PokemonCard {
  id: string;
  name: string;
  number: string;
  nationalPokedexNumbers?: number[];
  images: {
    small: string;
    large: string;
  };
  types?: string[];
  hp?: string;
  supertype?: string;
  subtypes?: string[];
  rarity?: string;
  artist?: string;
  flavorText?: string;
  attacks?: {
    name: string;
    damage: string;
    text?: string;
  }[];
  set?: {
    name: string;
    series: string;
  };
}

export interface PokemonListResponse {
  data: PokemonCard[];
  page: number;
  pageSize: number;
  count: number;
  totalCount: number;
}

export interface PokemonDetailResponse {
  data: PokemonCard;
}
