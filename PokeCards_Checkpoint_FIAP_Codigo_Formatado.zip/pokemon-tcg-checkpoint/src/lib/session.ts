import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";

export const COOKIE_NAME = "pokemon_session";

function getSecret(): string {
  const secret = process.env.SESSION_SECRET;
  if (!secret || secret.length < 32) {
    throw new Error("Configure SESSION_SECRET com pelo menos 32 caracteres.");
  }
  return secret;
}

export function createSession(username: string): string {
  const payload = Buffer.from(JSON.stringify({
    username,
    expires: Date.now() + 1000 * 60 * 60 * 24
  })).toString("base64url");

  const signature = createHmac("sha256", getSecret()).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

export function validateSession(token?: string): string | null {
  if (!token) return null;
  const [payload, signature] = token.split(".");
  if (!payload || !signature) return null;

  const expected = createHmac("sha256", getSecret()).update(payload).digest();
  const received = Buffer.from(signature, "base64url");

  if (expected.length !== received.length || !timingSafeEqual(expected, received)) {
    return null;
  }

  try {
    const session = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (typeof session.username !== "string" || session.expires < Date.now()) return null;
    return session.username;
  } catch {
    return null;
  }
}

export async function getLoggedInUser(): Promise<string | null> {
  const cookieStore = await cookies();
  return validateSession(cookieStore.get(COOKIE_NAME)?.value);
}
