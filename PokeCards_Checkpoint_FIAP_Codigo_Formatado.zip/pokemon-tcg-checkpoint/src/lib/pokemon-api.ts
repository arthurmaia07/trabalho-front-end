import type { PokemonDetailResponse, PokemonListResponse } from "@/types/pokemon";

const API_URL = "https://api.pokemontcg.io/v2/cards";

function getHeaders(): HeadersInit {
  const key = process.env.POKEMON_TCG_API_KEY;
  return key ? { "X-Api-Key": key } : {};
}

export async function listCards(search: string): Promise<PokemonListResponse> {
  const params = new URLSearchParams();
  params.set("pageSize", "15");
  params.set("page", "1");
  params.set("orderBy", "number,name");

  // A pesquisa usa a sintaxe definida na documentação da Pokémon TCG API.
  if (search) {
    const safeSearch = search.replace(/[^a-zA-Z0-9À-ÿ -]/g, " ").trim();
    if (safeSearch) params.set("q", `name:*${safeSearch.split(/\s+/).join("*")}*`);
  }

  const response = await fetch(`${API_URL}?${params.toString()}`, {
    headers: getHeaders(),
    next: { revalidate: 60 }
  });

  if (!response.ok) {
    throw new Error(response.status === 429
      ? "Limite de requisições da API atingido. Tente novamente em instantes."
      : "Não foi possível buscar as cartas no momento.");
  }

  return response.json() as Promise<PokemonListResponse>;
}

export async function getCard(id: string): Promise<PokemonDetailResponse> {
  const response = await fetch(`${API_URL}/${encodeURIComponent(id)}`, {
    headers: getHeaders(),
    next: { revalidate: 300 }
  });

  if (!response.ok) throw new Error("Não foi possível carregar os detalhes desta carta.");
  return response.json() as Promise<PokemonDetailResponse>;
}
