/// <reference types="next" />
/// <reference types="next/image-types/global" />
// Arquivo de tipos usado pelo Next.js.
