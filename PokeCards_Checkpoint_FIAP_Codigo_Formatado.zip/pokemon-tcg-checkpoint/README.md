# PokéCards — Checkpoint FIAP

Projeto de **Front-end Design Engineering** desenvolvido com **Next.js, App Router, React e TypeScript**. A aplicação consulta a [Pokémon TCG API v2](https://docs.pokemontcg.io/) para mostrar cartas, permite pesquisa pelo nome e gerencia uma lista pessoal de favoritos.

## Integrantes do trio (preencher antes da entrega)

- Nome completo 1: **PREENCHER** — RA: **PREENCHER**
- Nome completo 2: **PREENCHER** — RA: **PREENCHER**
- Nome completo 3: **PREENCHER** — RA: **PREENCHER**

> **ATENÇÃO:** edite também os integrantes no rodapé do arquivo `src/components/AppShell.tsx`.

## Link público do deploy na Vercel

**PREENCHER APÓS REALIZAR O DEPLOY:** https://SEU-PROJETO.vercel.app

Utilize o link público do site, **não** o link de preview/painel da Vercel.

## Tecnologias

- Next.js 15 (estrutura `src/app` obrigatória, sem pasta `pages`)
- React 19, TypeScript
- CSS puro em `src/app/globals.css` (sem CSS inline)
- Pokémon TCG API v2
- Cookies de sessão, API Routes e localStorage

## Como rodar o projeto

1. Instale Node.js 20 ou superior.
2. Abra a pasta no VS Code e execute `npm install`.
3. Crie o arquivo `.env.local` na raiz, copiando `.env.example`.
4. Configure uma senha em `LOGIN_PASSWORD` e um segredo de ao menos 32 caracteres em `SESSION_SECRET`.
5. Rode `npm run dev` e abra `http://localhost:3000`.
6. Faça login com qualquer nome de usuário não vazio e a senha definida em `.env.local`.

**Exemplo de `.env.local` para testes locais:**

```env
LOGIN_PASSWORD=MinhaSenhaForte123
SESSION_SECRET=segredo-local-para-testes-com-mais-de-32-caracteres
POKEMON_TCG_API_KEY=
```

O campo de API key é **opcional**; sem chave, a API aplica limites de uso menores. Nunca faça commit do `.env.local`.

## O que foi implementado (critérios da prova)

| Critério | Implementação |
| --- | --- |
| Organização e tipagem | Componentes, context, lib, types, Next App Router |
| Login | Página `/login` com usuário e senha |
| API Handler para autenticação | POST `/api/auth/login` comparando senha do ambiente |
| Erros e persistência de login | Mensagens no formulário e cookie assinado por 24h |
| Busca e lista | GET da API por `/api/cards`, até 15 cartas |
| Campos | Nome, imagem, Pokédex, tipo e HP |
| Busca por texto | Consulta à API com parâmetro `q`, com debounce |
| Favoritos | Botão de adicionar/remover favoritos |
| localStorage | Favoritos salvos por usuário e restaurados ao recarregar |
| Logout | Botão no topo, limpa os favoritos e a sessão |
| Extra: detalhes | Página `/cartas/[id]` com informações adicionais |
| Extra: favoritar nos detalhes | Botão de adicionar/remover na tela de detalhes |
| Deploy | Projeto preparado; publicação na Vercel precisa ser realizada pela equipe |

## Estrutura de pastas

```text
src/
  app/
    api/
      auth/login/route.ts
      auth/logout/route.ts
      cards/route.ts
      cards/[id]/route.ts
    cartas/[id]/page.tsx
    login/page.tsx
    globals.css
    layout.tsx
    page.tsx
  components/
    AppShell.tsx
    CardItem.tsx
    DetailsContent.tsx
    Header.tsx
    HomeContent.tsx
  context/
    FavoritesContext.tsx
  lib/
    pokemon-api.ts
    session.ts
  types/
    pokemon.ts
```

## Como funciona a autenticação

O login exige um nome de usuário e confere **somente uma senha fixa** no servidor, como solicitado. O servidor gera um cookie de sessão assinado, `HttpOnly`, que mantém o login ao atualizar a página. Não há banco de dados nem cadastro. Rotas privadas e rotas da API verificam a sessão. O logout remove a sessão e apaga os favoritos locais daquele usuário.

## Imagens das cartas

As imagens reais são fornecidas pelo campo `images.small` e `images.large` da API. Elas são carregadas pelo `next/image`. Não foram incluídas imagens estáticas de cartas no ZIP porque o exercício exige buscar os dados e as imagens pela API.

## Deploy na Vercel

1. Crie um repositório no GitHub e envie esta pasta (sem `.env.local`, `.next` ou `node_modules`).
2. Importe o repositório em https://vercel.com/new.
3. Framework Preset: **Next.js**.
4. Em Environment Variables, configure `LOGIN_PASSWORD` e `SESSION_SECRET`. A API key é opcional.
5. Clique em Deploy.
6. Abra o endereço público que termina em `.vercel.app` e teste login, busca, favoritos, refresh, detalhes e logout.
7. Cole o endereço público neste README e faça um novo commit.

## Testes recomendados antes da entrega

- [ ] Usuário vazio ou senha errada não autentica.
- [ ] Login correto leva para a lista.
- [ ] Atualizar a página não desloga.
- [ ] A lista apresenta no máximo 15 cartas com todos os campos.
- [ ] Digitar Pikachu ou Charizard traz resultados da API.
- [ ] Favoritos resistem ao refresh da página.
- [ ] Detalhes abrem e permitem adicionar/remover favorito.
- [ ] Logout limpa favoritos e bloqueia a área privada.
- [ ] Nomes completos e RAs aparecem no rodapé.
- [ ] Deploy público e URL no README.

## Observações

A Pokémon TCG API v2 é um serviço de terceiros e pode apresentar indisponibilidade ou limitação de requisições. O site mostra mensagens de erro quando ela falha. Os arquivos ignorados pelo `.gitignore` não devem ser incluídos na entrega.
